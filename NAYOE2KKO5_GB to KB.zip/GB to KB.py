gb=float(input())
kb=gb*1000
print(kb)